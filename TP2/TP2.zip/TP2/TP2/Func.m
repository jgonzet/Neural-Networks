% --------------------------------------------------------
%	
%	Funcion :  Funcion a utilizar.
%	Beta :  Define la pendiente en cero	 
%
%---------------------------------------------------------

function  [Result] = Func(value,Beta)
        
	Result = tanh(Beta*value) ;

end







