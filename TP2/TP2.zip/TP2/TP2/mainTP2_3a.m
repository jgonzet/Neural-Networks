clear all;
close all

ptos = 10;

x = linspace(0,2*pi,ptos)';
y = linspace(0,2*pi,ptos)';
z = linspace(-1,1,ptos)';

P = zeros(10,3);
permX = randperm(ptos);
permY = randperm(ptos);
permZ = randperm(ptos);
for i=1:ptos
    P(i,:) = [x(permX(i)) y(permY(i)) z(permZ(i))];
end

f = sin(P(:,1)) + cos(P(:,2)) + P(:,3);

beta = 1;


hi = w*





gFunction = tanh(beta*)






